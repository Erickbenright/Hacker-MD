<div class = "repo" align = "center">
 
<a href = "#">
<img src = "https://raw.githubusercontent.com/Niko-AND-Janiya/ANJU-DATA/refs/heads/main/LOGOS/6152181515400889311.jpg"  width="540" height="300">
</img>
 <p align="center">
  <a href="#"><img src="http://readme-typing-svg.herokuapp.com?color=ff00ab&center=true&vCenter=true&multiline=false&lines=QUEEN+ANJU+WHATSAPP+BOT+MD+V2" alt="">
</p>
    <p align="center">
<a href="#"><img title="Creator" src="https://img.shields.io/badge/Creator-GAMING_RASH-red.svg?style=for-the-badge&logo=github"></a>
<a href="#"><img title="LOGO DESIGNER" src="https://img.shields.io/badge/LOGO_DESIGNER-NIKO_PAMIYA-red.svg?style=for-the-badge&logo=github"></a>

<a href = ""><img alt="GAMING RASH" src="https://img.shields.io/youtube/channel/subscribers/UChrUGbOqQ6BZUAAsffJPPsw" target="_blank" /></a>
</p>
<p align="center">
<a href="https://github.com/Mrrashmika?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/Mrrashmika?color=green&style=flat-square"></a>
<a href="https://github.com/Mrrashmika/QUEEN_ANJU_MD/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Mrrashmika/QUEEN_ANJU_MD?color=white&style=flat-square"></a>
<a href="https://github.com/Mrrashmika/QUEEN_ANJU_MD/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Mrrashmika/QUEEN_ANJU_MD?color=yellow&style=flat-square"></a>
<a href="https://github.com/Mrrashmika/QUEEN_ANJU_MD/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Mrrashmika/QUEEN_ANJU_MD?label=Watchers&color=red&style=flat-square"></a>
<a href="https://github.com/Mrrashmika/QUEEN_ANJU_MD"><img title="Size" src="https://img.shields.io/github/repo-size/Mrrashmika/QUEEN_ANJU_MD?style=flat-square&color=darkred"></a>
<a href="https://github.com/Mrrashmika/QUEEN_ANJU_MD/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained-No-red.svg"></a>&nbsp;&nbsp;

### Please Read !
Queen Anju is a whatsapp bot created by Gaming rash ( Janith Rashmika ) using baileys web api. Do not use this bot in a way that will cause trouble to others. 
We are not responsible for any problems caused by your use of this!
And Subscribe GAMING RASH and give one star for queen anju.
</br>
#### Give One star For Queen Anju and [Follow Me](https://github.com/Mrrashmika) 

## How create queen Anju.

**. Deploy steps.*
 - 1._Fork queen Anju repository._
    <br>
    <a href="https://github.com/Mrrashmika/QUEEN_ANJU_MD/fork"><img title="QUEEN_ANJU-MD" src="https://img.shields.io/badge/FORK QUEEN_ANJU-h?color=black&style=for-the-badge&logo=stackshare"></a>
 - 2._Link with yoour whatsappp using pair code._
   **Pair with WhatsApp* 
   <p align="center">
       <a href="https://multiple-kingfisher-gamingrash-6eb80034.koyeb.app/">
         <img src="https://play-lh.googleusercontent.com/901aMQFFnVoX2T-YuJmTIwpPve_SUgMv_QSyzMSPtAqt_l0CyXN1DxfD6xXU0r2f9iM=w240-h480-rw" width="90" />
       </a>
   </p>
 - _Open config.js on your forked repository. and put `SESSION_ID` and change other settings you need._
 - _Deploy using your host._
   </br>

  1..DEPLOY ON RENDER

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/Mrrashmika/QUEEN_ANJU_MD.git)

***<p align="center"> • [`Tap here for Render tutorial`](https://youtu.be/aIUe2sEmd_E?si=WiL0IMrI79GJuog9) </p>***

   2..DEPLOY ON GITHUB

***<p align="center"> • [`Tap here for Github deploy tutorial`](https://youtu.be/NHxe-ynZmGI) </p>***

   3..DEPLOY ON KOYEB

[![Deploy to Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/deploy?name=queen-anju-md&type=git&repository=Mrrashmika%2FQueen_Anju-MD&branch=V-2.00&builder=dockerfile&env%5BMONGODB%5D=your+mongodb+uri&env%5BSESSION_ID%5D=your+session+id&ports=8000%3Bhttp%3B%2F)

   4..DEPLOY ON HEROKU

 [![nima](https://img.shields.io/badge/Queen_Anju_md_deploy_on_heroku-430098?style=for-the-badge&logo=heroku&logoColor=white&buttcode=1n2i3m4a)](https://dashboard.heroku.com/new?template=https://github.com/Mrrashmika/QUEEN_ANJU_MD)
